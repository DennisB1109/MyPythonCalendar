# MyPythonCalendar
Here I will create my first project in Python, which will be to create a calendar that I can use in my daily life

Not for myself:
To build the executable with PyInstaller input the following command in the CMD commando line
python -m PyInstaller --onefile --noconsole --icon=Apple_Calendar_Icon.ico -n CalendarV2.0 --add-data my_Events.xlsx;icluded myCalendar.py --distpath .
